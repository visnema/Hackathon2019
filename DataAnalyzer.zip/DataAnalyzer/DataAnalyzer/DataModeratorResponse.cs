﻿using System.Collections.Generic;
public class Category1
{
    public double Score { get; set; }
}

public class Category2
{
    public double Score { get; set; }
}

public class Category3
{
    public double Score { get; set; }
}

public class Classification
{
    public Category1 Category1 { get; set; }
    public Category2 Category2 { get; set; }
    public Category3 Category3 { get; set; }
    public bool ReviewRecommended { get; set; }
}

public class Status
{
    public int Code { get; set; }
    public string Description { get; set; }
    public object Exception { get; set; }
}

public class PII
{
    public List<string> Email { get; set; }
    public List<string> SSN { get; set; }
    public List<string> IPA { get; set; }
    public List<string> Phone { get; set; }
    public List<string> Address { get; set; }
}

public class TermClass
{
    public int Index { get; set; }
    public int OriginalIndex { get; set; }
    public int ListId { get; set; }
    public string Term { get; set; }
}

public class DataModeratorResponse
{
    public string OriginalText { get; set; }
    public string NormalizedText { get; set; }
    public string AutoCorrectedText { get; set; }
    public object Misrepresentation { get; set; }
    public Classification Classification { get; set; }
    public Status Status { get; set; }
    public PII PII { get; set; }
    public string Language { get; set; }
    public List<TermClass> Terms { get; set; }
    public string TrackingId { get; set; }
}