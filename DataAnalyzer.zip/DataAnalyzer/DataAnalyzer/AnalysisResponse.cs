﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAnalyzer
{
    public class AnalysisResponse
    {
        public AnalysisResponse()
        {
            ProfaneWords = new Dictionary<string, int>();
            NonInclusiveWords = new Dictionary<string, int>();
            GenderBiasedWords = new Dictionary<string, int>();
            Languages = new Dictionary<string, int>();
        }
        public Dictionary<string, int> ProfaneWords;
        public Dictionary<string, int> NonInclusiveWords;
        public Dictionary<string, int> GenderBiasedWords;
        public Dictionary<string, int> Languages;

        public int ProfaneWordsScore = 0;
        public int NonInclusiveWordsScore = 0;
        public int GenderBiasedWordsScore = 0;
        public int LanguagesScore = 0;

        public int ProfaneWordsBias = 0;
        public int NonInclusiveWordsBias = 0;
        public int GenderBiasedWordsBias = 0;
        public int LanguagesBias = 0;

        public int TotalScore = 0;
        public int Rating = 0;
        public int AverageScore = 0;    
        
    }
}
