using Microsoft.Azure.CognitiveServices.ContentModerator;
using Microsoft.CognitiveServices.ContentModerator;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace DataAnalyzer
{
    class Program
    {
        /// <summary>
        /// The name of the file that contains the text to evaluate.
        /// </summary>
        /// <remarks>You will need to create an input file and update this path
        /// accordingly. Relative paths are relative to the execution directory.</remarks>
        private static string TextFilePath = @"C:\Users\dekumars\Desktop\Data\Data.txt";

        private static string NonInclusiveWordsListFilePath = @"C:\Users\dekumars\Desktop\Data\NonInclusiveWords.txt";

        private static string GenderBiasedWordsListFilePath = @"C:\Users\dekumars\Desktop\Data\GenderBiasedWords.txt";

        /// <summary>
        /// The name of the file to contain the output from the evaluation.
        /// </summary>
        /// <remarks>Relative paths are relative to the execution directory.</remarks>
        private static string OutputFile = @"C:\Users\dekumars\Desktop\Data\Output.txt";

        private static List<string> NonInclusiveWords;
        private static List<string> GenderBiasedWords;

        private static AnalysisResponse dataResponse;

        static Program()
        {
            PopulateNonInclusiveWords();
            PopulateGenderBiasedWords();

        }

        static void Main(string[] args)
        {
            string inputText = ReadInputData(TextFilePath);
            inputText = inputText.Replace(System.Environment.NewLine, " ");

            AnalyzeInputData(inputText);
            

            OutputResponse(OutputFile);
            CalculateScore();
            //var result = GetResponseFromDataModerator(inputText);

            //AnalyzeData(result);
        }
        private static void CalculateScore()
        {

            dataResponse.ProfaneWordsScore = (dataResponse.ProfaneWords.Count)*(dataResponse.ProfaneWordsBias);
            dataResponse.NonInclusiveWordsScore = (dataResponse.NonInclusiveWords.Count)*(dataResponse.NonInclusiveWordsBias);
            dataResponse.GenderBiasedWordsScore = (dataResponse.GenderBiasedWords.Count)*(dataResponse.GenderBiasedWordsBias);
            dataResponse.LanguagesScore = (dataResponse.Languages.Count)*(dataResponse.LanguagesBias);
            int totalBias = 10;
            dataResponse.TotalScore = dataResponse.ProfaneWordsScore + dataResponse.NonInclusiveWordsScore
                + dataResponse.GenderBiasedWordsScore + dataResponse.LanguagesScore;
            dataResponse.AverageScore = dataResponse.TotalScore / totalBias;
            dataResponse.Rating = 5;
        }
        private static void OutputResponse(string OutputFile)
        {
            using (StreamWriter outputWriter = new StreamWriter(OutputFile, false))
            {
                outputWriter.WriteLine(
                        JsonConvert.SerializeObject(dataResponse, Formatting.Indented));
                outputWriter.Flush();
                outputWriter.Close();
            }
        }

        private static void AnalyzeInputData(string inputText)
        {
            int? cnt;
            DataModeratorResponse response = null;
            //InputToDataAnalyzer inputData = JsonConvert.DeserializeObject<InputToDataAnalyzer>(inputText);
            dataResponse = new AnalysisResponse();

            foreach (var item in NonInclusiveWords)
            {
                cnt = Regex.Matches(inputText, item, RegexOptions.IgnoreCase)?.Count;
                if(cnt.HasValue && cnt > 0)
                {
                    dataResponse.NonInclusiveWords.Add(item, cnt ?? 0);
                }
            }

            foreach (var item in GenderBiasedWords)
            {
                cnt = Regex.Matches(inputText, item, RegexOptions.IgnoreCase).Count;
                if (cnt.HasValue && cnt > 0)
                {
                    dataResponse.GenderBiasedWords.Add(item, cnt ?? 0);
                }
            }

            var sentences = inputText.Split('.');
            foreach (var sentence in sentences)
            {
                if (String.IsNullOrWhiteSpace(sentence))
                    continue;
                //private static DataModeratorResponse GetResponseFromDataModerator(string inputText)
                response = GetResponseFromDataModerator(sentence.Trim());

                if(response?.Terms?.Count>0)
                {
                    foreach (var item in response.Terms)
                    {
                        if(dataResponse.ProfaneWords.ContainsKey(item.Term.Trim(' ').ToLower()))
                        {
                            dataResponse.ProfaneWords[item.Term.Trim(' ').ToLower()]++;
                        }
                        else
                        {
                            dataResponse.ProfaneWords[item.Term.Trim(' ').ToLower()] = 1;
                        }
                    }
                }

                if (dataResponse.Languages.ContainsKey(response.Language.ToLower()))
                    dataResponse.Languages[response.Language.ToLower()]++;
                else
                    dataResponse.Languages[response.Language.ToLower()] = 1;
            }

        }

        private static void AnalyzeData(DataModeratorResponse result)
        {
            string correctedText = result.AutoCorrectedText;
            int cntNIW = 0, cntGBW = 0, cntPW = 0;

            dataResponse = new AnalysisResponse();

            foreach (var item in NonInclusiveWords)
            {
                cntNIW += Regex.Matches(correctedText, item, RegexOptions.IgnoreCase).Count;
            }

            foreach (var item in GenderBiasedWords)
            {
                cntGBW += Regex.Matches(correctedText, item).Count;
            }

            cntPW = result.Terms.Count;

            //dataResponse.




        }

        private static string ReadInputData(string TextFilePath)
        {
            string text;
            if (!File.Exists(TextFilePath))
                Console.WriteLine(String.Format("Input file doesn't exist at location: {0}", TextFilePath));
            try
            {
                text = File.ReadAllText(TextFilePath);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return text;
        }

        private static void PopulateGenderBiasedWords()
        {
            string genderBiasedWords = ReadInputData(GenderBiasedWordsListFilePath);
            genderBiasedWords = genderBiasedWords.Replace(System.Environment.NewLine, ",");
            var genderBiasedWordsList = genderBiasedWords.Split(',');

            GenderBiasedWords = new List<string>();

            foreach (var item in genderBiasedWordsList)
            {
                if (!String.IsNullOrWhiteSpace(item))
                {
                    GenderBiasedWords.Add(item.Trim(' '));
                }
            }
        }

        private static void PopulateNonInclusiveWords()
        {
            string nonInclusiveWords = ReadInputData(NonInclusiveWordsListFilePath);
            nonInclusiveWords = nonInclusiveWords.Replace(System.Environment.NewLine, ",");
            var nonInclusiveWordsList = nonInclusiveWords.Split(',');

            NonInclusiveWords = new List<string>();

            foreach (var item in nonInclusiveWordsList)
            {
                if(!String.IsNullOrWhiteSpace(item))
                {
                    NonInclusiveWords.Add(item.Trim(' '));
                }
            }
        }

        private static DataModeratorResponse GetResponseFromDataModerator(string inputText)
        {
            DataModeratorResponse response = null;

            using (var client = Clients.NewClient())
            {
                // Screen the input text: check for profanity, classify the text into three categories,
                // do autocorrect text, and check for personally identifying 
                // information (PII)
                
                var screenResult =
                    client.TextModeration.ScreenText("text/plain", new MemoryStream(Encoding.UTF8.GetBytes(inputText)), null, true, true, null, true);
                response = JsonConvert.DeserializeObject<DataModeratorResponse>(JsonConvert.SerializeObject(screenResult, Formatting.Indented));
            }

            return response;
        }
    }

    /// <summary>
    /// Wraps the creation and configuration of a Content Moderator client.
    /// </summary>
    /// <remarks>This class library contains insecure code. If you adapt this 
    /// code for use in production, use a secure method of storing and using
    /// your Content Moderator subscription key.</remarks>
    public static class Clients
    {
        // TODO We could make team name a static property on this class, to move all of the subscription information into one project.

        /// <summary>
        /// The region/location for your Content Moderator account, 
        /// for example, westus.
        /// </summary>
        private static readonly string AzureRegion = "westus";

        /// <summary>
        /// The base URL fragment for Content Moderator calls.
        /// </summary>
        private static readonly string AzureBaseURL =
            $"https://{AzureRegion}.api.cognitive.microsoft.com";

        /// <summary>
        /// Your Content Moderator subscription key.
        /// </summary>
        private static readonly string CMSubscriptionKey = "d3f8ce1abcd94654a14d57bf9f1e2029";

        /// <summary>
        /// Returns a new Content Moderator client for your subscription.
        /// </summary>
        /// <returns>The new client.</returns>
        /// <remarks>The <see cref="ContentModeratorClient"/> is disposable.
        /// When you have finished using the client,
        /// you should dispose of it either directly or indirectly. </remarks>
        public static ContentModeratorClient NewClient()
        {
            // Create and initialize an instance of the Content Moderator API wrapper.
            ContentModeratorClient client = new ContentModeratorClient(new ApiKeyServiceClientCredentials(CMSubscriptionKey));

            client.Endpoint = AzureBaseURL;
            return client;
        }
    }
}
