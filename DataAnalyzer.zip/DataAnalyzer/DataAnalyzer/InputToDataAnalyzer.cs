﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAnalyzer
{
    public class InputToDataAnalyzer
    {
        List<Conversation> Conversations;
        List<string> Participants;
        DateTime MeetingDate;
        string Subject;

    }

    public class Conversation
    {
        string UserId;
        string Text;
    }
    
}
